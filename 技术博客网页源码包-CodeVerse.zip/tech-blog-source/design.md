# CodeVerse · 终端诗学 — 设计规范（design.md）

> 本文档与 `index.html` 同包交付，描述页面的完整设计令牌与组件规格，供开发接管与二次定制使用。

## 1. 设计理念

**终端诗学（Terminal Poetics）**：所有视觉语言取自开发者最熟悉的终端窗口——深靛蓝夜幕、琥珀色提示符、等宽字体、玻璃拟态面板。目标是唤起「深夜写代码」的专注与温柔。

## 2. 色彩令牌

| 令牌 | 值 | 用途 |
| --- | --- | --- |
| `--bg-0` | `#0a0e1a` | 页面底色（深靛蓝夜幕） |
| `--bg-1` | `#111830` | 面板 / 输入框底色 |
| `--bg-2` | `#182142` | Toast / 悬浮层底色 |
| `--ink` | `#e8ecf8` | 主文本（对比度 vs bg-0 ≈ 15:1） |
| `--ink-2` | `#aab4d4` | 次级文本（≈ 8:1） |
| `--ink-3` | `#8290b4` | 弱化文本 / 元信息（≥ 4.5:1） |
| `--amber` | `#ffb454` | 主强调色：选中态、主按钮、光标 |
| `--amber-ink` | `#1a1206` | 琥珀底上的深色文字 |
| `--mint` | `#4ade80` | 语义色：成功 / 已采纳 / 终端提示 |
| `--violet` | `#a78bfa` | 语义色：徽章 / 分类 |
| `--rose` | `#fb7185` | 语义色：点赞 / 删除 / 进度渐变 |
| `--cyan` | `#67e8f9` | 语义色：回答数 / 代码 |
| `--line` | `rgba(255,255,255,.08)` | 常规描边 |
| `--line-strong` | `rgba(255,255,255,.16)` | 悬停 / 强描边 |
| `--glass` | `rgba(17,24,48,.72)` | 玻璃拟态底（配 backdrop-blur 18px） |

## 3. 字体

| 令牌 | 字体栈 | 用途 |
| --- | --- | --- |
| `--font-mono` | `'JetBrains Mono','SF Mono','Cascadia Code',Consolas,'Courier New',monospace` | 代码窗口、面包屑、元信息、数字、时间 |
| `--font-sans` | `-apple-system,BlinkMacSystemFont,'Segoe UI','PingFang SC','Hiragino Sans GB','Microsoft YaHei','Noto Sans SC',sans-serif` | 正文、标题 |

全部为系统字体栈，**零外部字体请求**，离线可用。字形回退顺序保证中西文混排一致。

## 4. 字号 / 间距 / 圆角 / 阴影

- 字号阶梯（px）：`11 / 12 / 13 / 13.5 / 14 / 14.5 / 15 / 16 / 16.5 / 20 / 24 / 26(clamp至42) `；正文行高 `1.65`，标题行高 `1.28–1.5`。全站不使用 pt 单位。
- 间距令牌（8px 栅格派生）：`--s1:4 · --s2:8 · --s3:12 · --s4:16 · --s5:24 · --s6:32 · --s7:48`
- 圆角：`--r-lg:16px`（容器）/ `--r-md:12px`（按钮、卡片内件）/ `--r-sm:8px`（小件、标签）
- 阴影：`--shadow: 0 12px 32px rgba(2,6,18,.55)`；主按钮悬浮投影 `0 10px 26px rgba(255,180,84,.4)`

## 5. 断点与响应式

| 断点 | 行为 |
| --- | --- |
| `> 1024px` | 桌面：固定左侧栏 236px + 主内容栅格；Hero 双栏 |
| `≤ 1024px` | Hero 折单栏；问答两栏折单栏（历史面板下移） |
| `≤ 768px` | 侧栏隐藏，底部 5-Tab 导航；音乐坞全宽贴底；主内容留出 210px 底距 |
| `≤ 480px` | 紧凑模式：文章网格单列、搜索行纵排、投票区横排、面包屑隐藏 |
| `prefers-reduced-motion: reduce` | 全部动画/过渡降至 0.001s，粒子静止 |

## 6. 组件状态

| 组件 | 状态矩阵 |
| --- | --- |
| 导航按钮 `nav-btn` | default / hover(背景提亮) / current(琥珀底+左侧光条, `aria-current="page"`) |
| 筛选 Chip | default / hover / pressed(`.on` + `aria-pressed="true"`) |
| 卡片 `card` | default / hover(上浮 5px + 描边提亮，250ms cubic-bezier) |
| 点赞按钮 | default / hover(玫红描边) / pressed(`aria-pressed="true"` 玫红填充) |
| 搜索输入 | default / focus(琥珀描边 + 3px 光晕 `box-shadow`) |
| 主按钮 | default / hover(上浮 2px + 投影加深) |
| 我的 Tab | default / hover / selected(`aria-selected="true"` + 底部琥珀条) |
| 唱片 | 静止 / 播放中(4s 匀速旋转) |

## 7. 交互规则

- **路由**：五个页面（home / community / qa / me / about）为同文档切换，激活面板 `.active`，进场动画 450ms；面包屑随路由更新为 `~/codeverse/<page>`。
- **快捷键**：`/` 聚焦搜索（输入态下不劫持）；`Enter` 提交搜索；进度条支持 `←/→` 键盘步进（±5%）。
- **搜索历史**：存 `localStorage['cv_search_history']`，最多 8 条、去重、新条目置顶；逐条删除 / 一键清空均有 Toast 反馈；数据仅存本机。
- **音乐**：Web Audio API 本地合成（和弦铺底 + 三角波低音 + 底鼓 + 踩镲 + 五声音阶随机旋律），4 首曲目不同 BPM/调性/波形；AnalyserNode 驱动频谱可视化；播放时粒子背景速度 ×2.4。首次播放需用户手势（浏览器自动播放策略），页面加载不自动出声。
- **反馈**：全局 Toast（底部居中，2.2s 自动消失，`role="status"` 供读屏播报）。

## 8. 无障碍基线

- 正文对比度 ≥ 4.5:1（`--ink-3` 为最弱文本色，实测 ≥ 4.5:1）；大字与图形 ≥ 3:1。
- 所有可交互元素为 `<button>`，带 `aria-label` / `aria-pressed` / `aria-current` / `aria-selected` / `role` 等语义属性。
- `:focus-visible` 全局琥珀色 2px 外描边；滑块可键盘操作。
- `<html lang="zh-CN">`；装饰性 canvas 与符号标 `aria-hidden="true"`。

## 9. 已知限制

- 站内文章 / 帖子 / 问答 / 用户数据均为**演示数据**（内嵌于 JS 常量），无后端；正式使用需接入真实数据源。
- 背景音乐为程序化合成，音色为 Lo-Fi 风格示意；如需真实曲目，可在 `Music` 模块中替换为 `<audio>` + 音频文件。
- 「我的」页面为演示档案，未做登录体系。
